-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 12-Jun-2019 às 02:01
-- Versão do servidor: 10.1.35-MariaDB
-- versão do PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `study_today`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro_login`
--

CREATE TABLE `cadastro_login` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `hash` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cadastro_login`
--

INSERT INTO `cadastro_login` (`id`, `nome`, `email`, `senha`, `hash`) VALUES
(25, 'Rafaela', 'faelacastro16@gmai.com', '123', 'CpYpYoZsVT0sdtjJ4Lhp2613NThiMDcC'),
(26, 'Izael', 'izaelred@gmail.com', '1', 'K0zCZPDsH3COZxKVNOfn0OKPHmerrJs1'),
(27, 'Rafaela', 'faelacastro16@gmail.com', '1', '7aZGjX79sEKAspjaZuHin8hfkCdp858H'),
(28, 'Lucas Gostozao', 'luquihas123cat@gmai.com', 'Hungria', 'Es4c2M7zunKY8l5CK7RcgBRIJ2RDBMGO'),
(29, 'Lucas Gostozao', 'luquihas1234cat@gmai.com', '1', 'qWBYGy717OCYLedyapQkpSR8otkzww8D'),
(30, 'Lucas Gostozao', 'lucas123@gmail.com', '123', '0oGWEq8Ey22z2hD5PIHqWmj6mvciwT3w'),
(31, 'Ullisse', 'uli@gmail.com', 'uli', 'DMxUBJGDDKcZXZtDrwi50FTYPqWk7o5w'),
(32, 'Cris', 'cris@gmail.com', '1', 'Q57pah4fUSwJEmpmo1qkDlnz97B1OwGD'),
(33, 'Gu', 'Guu@gmail.com', '2', 'iSd6sutEyfNoA5S2jfZZzeEHKfG8qWue'),
(34, 'RO', 'ROBERO2211@GMAIL.COM', '123', '1gLcXD26lmYij7sBO4IHBG5lWiNI5yKr');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cadastro_login`
--
ALTER TABLE `cadastro_login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `nome` (`nome`) USING BTREE,
  ADD KEY `senha` (`senha`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cadastro_login`
--
ALTER TABLE `cadastro_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
